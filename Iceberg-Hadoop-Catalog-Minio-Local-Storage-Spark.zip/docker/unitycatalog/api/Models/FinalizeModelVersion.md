# FinalizeModelVersion
## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
| **full\_name** | **String** | The full name of the registered model to finalize. | [default to null] |
| **version** | **Long** | Version number of the version to finalize. | [default to null] |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

