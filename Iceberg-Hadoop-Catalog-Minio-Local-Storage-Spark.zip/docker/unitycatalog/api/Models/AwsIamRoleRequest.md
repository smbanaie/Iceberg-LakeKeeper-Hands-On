# AwsIamRoleRequest
## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
| **role\_arn** | **String** | The Amazon Resource Name (ARN) of the AWS IAM role used to vend temporary credentials. | [default to null] |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

