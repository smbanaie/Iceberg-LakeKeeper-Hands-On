# UpdatePermissions
## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
| **changes** | [**List**](PermissionsChange.md) | Array of permissions change objects. | [default to null] |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

