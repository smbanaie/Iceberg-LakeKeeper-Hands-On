# PrivilegeAssignment
## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
| **principal** | **String** | The principal (user email address or group name). | [default to null] |
| **privileges** | [**List**](Privilege.md) | The privileges assigned to the principal. | [default to null] |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

