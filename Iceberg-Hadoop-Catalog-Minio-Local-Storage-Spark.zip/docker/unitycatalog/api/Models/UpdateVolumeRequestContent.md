# UpdateVolumeRequestContent
## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
| **comment** | **String** | The comment attached to the volume | [optional] [default to null] |
| **new\_name** | **String** | New name for the volume. | [optional] [default to null] |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

