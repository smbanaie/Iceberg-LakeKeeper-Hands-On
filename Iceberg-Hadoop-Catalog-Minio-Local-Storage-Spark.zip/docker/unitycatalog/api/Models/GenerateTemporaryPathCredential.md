# GenerateTemporaryPathCredential
## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
| **url** | **String** | The URL of the storage path for which temporary credentials need to be generated. | [default to null] |
| **operation** | [**PathOperation**](PathOperation.md) |  | [default to null] |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

