from unitycatalog.ai.litellm.version import VERSION

__version__ = VERSION
