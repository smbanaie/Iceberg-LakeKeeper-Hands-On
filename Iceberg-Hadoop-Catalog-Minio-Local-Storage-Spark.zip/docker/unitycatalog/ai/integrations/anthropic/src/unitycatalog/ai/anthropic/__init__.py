from unitycatalog.ai.anthropic.version import VERSION

__version__ = VERSION
