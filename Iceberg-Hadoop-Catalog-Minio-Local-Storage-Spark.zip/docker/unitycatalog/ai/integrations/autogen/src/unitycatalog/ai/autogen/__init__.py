from unitycatalog.ai.autogen.version import VERSION

__version__ = VERSION
