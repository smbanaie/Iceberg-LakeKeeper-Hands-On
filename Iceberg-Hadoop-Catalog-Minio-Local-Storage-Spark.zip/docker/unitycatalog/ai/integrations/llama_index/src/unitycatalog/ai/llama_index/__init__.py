from unitycatalog.ai.llama_index.version import VERSION

__version__ = VERSION
