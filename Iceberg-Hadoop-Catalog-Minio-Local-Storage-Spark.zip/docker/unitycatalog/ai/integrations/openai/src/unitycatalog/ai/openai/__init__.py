from unitycatalog.ai.openai.version import VERSION

__version__ = VERSION
