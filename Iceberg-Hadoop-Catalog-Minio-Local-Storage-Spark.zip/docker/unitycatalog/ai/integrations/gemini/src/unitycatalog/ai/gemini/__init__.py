from unitycatalog.ai.gemini.version import VERSION

__version__ = VERSION
