from unitycatalog.ai.crewai.version import VERSION

__version__ = VERSION
